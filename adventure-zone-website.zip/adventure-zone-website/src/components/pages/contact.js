import React, { Component } from 'react';

class contact extends Component {
    render() {
        return (
            <div className="ContactNames">

                <p> Matt Lawlor </p>
                <p> Connor Kocolowski </p>
                <p> Hayes Hundman </p>
                <p> Emmett Kozlowski </p>
                <p> Brett Altena </p>
                <p> Tanner Hinders</p>

            </div>
        );
    }
}

export default contact;